-- ============================================
-- EXPLORATORY DATA ANALYSIS
-- ============================================

-- Overall Statistics
SELECT 
    COUNT(*) as total_employees,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) as employees_left,
    ROUND(AVG(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100, 2) as attrition_rate_pct
FROM employees;

-- Department Analysis
SELECT 
    department,
    COUNT(*) as total_employees,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) as employees_left,
    ROUND(AVG(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100, 2) as attrition_rate_pct,
    ROUND(AVG(monthly_income), 0) as avg_income
FROM employees
GROUP BY department
ORDER BY attrition_rate_pct DESC;

-- Job Role Analysis
SELECT 
    job_role,
    COUNT(*) as employee_count,
    ROUND(AVG(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100, 2) as attrition_rate_pct
FROM employees
GROUP BY job_role
HAVING COUNT(*) >= 10
ORDER BY attrition_rate_pct DESC;
