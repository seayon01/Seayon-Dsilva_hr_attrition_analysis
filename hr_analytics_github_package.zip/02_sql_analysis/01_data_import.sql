-- ============================================
-- HR ANALYTICS: DATA IMPORT SETUP
-- ============================================

CREATE TABLE employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    age INT,
    attrition VARCHAR(3),
    business_travel VARCHAR(50),
    department VARCHAR(100),
    distance_from_home INT,
    education INT,
    education_field VARCHAR(100),
    environment_satisfaction INT,
    gender VARCHAR(10),
    job_involvement INT,
    job_level INT,
    job_role VARCHAR(100),
    job_satisfaction INT,
    marital_status VARCHAR(20),
    monthly_income INT,
    num_companies_worked INT,
    overtime VARCHAR(3),
    percent_salary_hike INT,
    performance_rating INT,
    relationship_satisfaction INT,
    stock_option_level INT,
    total_working_years INT,
    training_times_last_year INT,
    work_life_balance INT,
    years_at_company INT,
    years_in_current_role INT,
    years_since_last_promotion INT,
    years_with_curr_manager INT,
    
    INDEX idx_attrition (attrition),
    INDEX idx_department (department),
    INDEX idx_job_role (job_role)
);

-- Verify data
SELECT COUNT(*) as total_records FROM employees;
